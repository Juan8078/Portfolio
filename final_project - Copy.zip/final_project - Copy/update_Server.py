import paho.mqtt.client as mqtt
import sqlite3
import json

DB = "iot.db"

def on_message(client, userdata, message):
    try:
        payload = json.loads(message.payload.decode())
    except:
        print("❌ Error: Invalid JSON received")
        return

    # Extract important fields
    device_id = payload.get("device_id")
    device_type = payload.get("device_type")
    password = payload.get("password")
    timestamp = payload.get("timestamp")
    message_id = payload.get("message_id")
    data_block = payload.get("data")

    # Validate mandatory fields
    if not (device_id and device_type and password and data_block):
        print("❌ Missing required fields:", payload)
        return

    # Validate password
    with sqlite3.connect(DB) as conn:
        cur = conn.cursor()
        cur.execute("SELECT password FROM devices WHERE device_id=?", (device_id,))
        row = cur.fetchone()

        if not row:
            print(f"⚠ Unknown device '{device_id}' — ignoring...")
            return

        if row[0] != password:
            print(f"❌ Wrong password for device '{device_id}'")
            return

        # Save each sensor key in data block
        for sensor_key, sensor_value in data_block.items():
            cur.execute("""
                INSERT INTO sensor_data (message_id, device_id, timestamp, data_type, value)
                VALUES (?, ?, ?, ?, ?)
            """, (message_id, device_id, timestamp, sensor_key, sensor_value))

        conn.commit()

    print(f"✅ Data stored from {device_id}: {data_block}")


# MQTT listener
client = mqtt.Client()
client.on_message = on_message

client.connect("broker.emqx.io", 1883, 60)
client.subscribe("devices_data/#")

print(" Server is running... Waiting for data...")
client.loop_forever()
