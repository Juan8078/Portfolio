import sqlite3

DB = "iot.db"

with sqlite3.connect(DB) as conn:
    cur = conn.cursor()

    # Table devices
    cur.execute("""
        CREATE TABLE IF NOT EXISTS devices (
            device_id TEXT PRIMARY KEY,
            device_type TEXT,
            password TEXT
        )
    """)

    # Table sensor_data
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sensor_data (
            message_id TEXT,
            device_id TEXT,
            timestamp REAL,
            data_type TEXT,
            value REAL
        )
    """)

    # Insert default devices
    devices = [
        ("device1", "environment_sensor", "secret1"),
        ("device2", "energy_sensor", "secret2")
    ]

    for d in devices:
        cur.execute("""
            INSERT OR IGNORE INTO devices (device_id, device_type, password)
            VALUES (?, ?, ?)
        """, d)

    conn.commit()

print("Database initialized!")
