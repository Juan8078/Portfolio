import paho.mqtt.client as mqtt
import json
import time
import uuid

BROKER = "broker.emqx.io"
PORT = 1883
TOPIC = "devices_data/device1"

DEVICE_ID = "device1"
PASSWORD = "secret1"

def on_connect(client, userdata, flags, rc):
    print("Connected with result code", rc)

client = mqtt.Client()
client.on_connect = on_connect

client.connect(BROKER, PORT, 60)

while True:
    payload = {
        "message_id": str(uuid.uuid4()),
        "device_id": DEVICE_ID,
        "device_type": "environment_sensor",
        "password": PASSWORD,
        "timestamp": time.time(),
        "data": {
            "temperature": 28.5,
            "humidity": 65.2,
            "noise": 45.1,
            "luminance": 320.0
        }
    }

    client.publish(TOPIC, json.dumps(payload))
    print("Sent:", payload)

    time.sleep(10)
