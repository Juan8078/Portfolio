import sqlite3
import matplotlib.pyplot as plt
from datetime import datetime

DB = "iot.db"

with sqlite3.connect(DB) as conn:
    cursor = conn.cursor()

    # Ambil data suhu dari semua device tipe environment_sensor
    cursor.execute("""
        SELECT s.timestamp, s.value 
        FROM sensor_data s
        JOIN devices d ON s.device_id = d.device_id
        WHERE d.device_type = 'environment_sensor'
          AND s.data_type = 'temperature'
        ORDER BY s.timestamp
    """)

    rows = cursor.fetchall()

# Jika tidak ada data → hindari error
if not rows:
    print("⚠ No temperature data found")
    exit()

timestamps = []
temperatures = []

# Convert timestamp ke datetime
for ts, temp in rows:
    try:
        timestamps.append(datetime.fromtimestamp(ts))
    except:
        timestamps.append(ts)    # fallback jika timestamp sudah string
    temperatures.append(temp)

plt.figure(figsize=(10,5))
plt.plot(timestamps, temperatures, label='Temperature (°C)', marker='o')
plt.xlabel('Timestamp')
plt.ylabel('Temperature (°C)')
plt.title('Temperature Over Time')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
