import paho.mqtt.client as mqtt
import json
import time
import uuid

BROKER = "broker.emqx.io"
PORT = 1883
TOPIC = "devices_data/device2"

DEVICE_ID = "device2"
PASSWORD = "secret2"

def on_connect(client, userdata, flags, rc):
    print("Connected with result code", rc)

client = mqtt.Client()
client.on_connect = on_connect

client.connect(BROKER, PORT, keepalive=60)

while True:
    payload = {
        "message_id": str(uuid.uuid4()),
        "device_id": DEVICE_ID,
        "device_type": "energy_sensor",
        "password": PASSWORD,
        "timestamp": time.time(),
        "data": {
            "energy_harvested": 25.6  # kWh
        }
    }

    client.publish(TOPIC, json.dumps(payload))
    print("Sent:", payload)

    time.sleep(10)
